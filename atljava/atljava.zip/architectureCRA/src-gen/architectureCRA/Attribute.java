/**
 */
package architectureCRA;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see architectureCRA.ArchitectureCRAPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends Feature {
} // Attribute
